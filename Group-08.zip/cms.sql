-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2022 at 07:09 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', '25d55ad283aa400af464c76d713c07ad', '27-08-2022 04:14:50 PM'),
(2, 'rakib', '25d55ad283aa400af464c76d713c07ad', '27-08-2022 04:41:50 PM');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(3, 'Data Problem', '', '2022-07-02 17:48:06', NULL),
(4, 'Call drop', '', '2022-08-27 10:40:26', NULL),
(5, '4G network', '', '2022-08-27 10:40:50', NULL),
(6, 'Balance problem', '', '2022-08-27 10:41:01', NULL),
(7, 'VAS problem', '', '2022-08-27 10:41:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `complaintremark`
--

CREATE TABLE `complaintremark` (
  `id` int(11) NOT NULL,
  `complaintNumber` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext DEFAULT NULL,
  `remarkDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaintremark`
--

INSERT INTO `complaintremark` (`id`, `complaintNumber`, `status`, `remark`, `remarkDate`) VALUES
(9, 24, 'closed', 'Solved', '2022-07-02 14:27:45');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `stateName` varchar(255) DEFAULT NULL,
  `stateDescription` tinytext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `stateName`, `stateDescription`, `postingDate`, `updationDate`) VALUES
(7, 'Dhaka', '', '2022-08-27 10:35:05', NULL),
(8, 'BOGRA', '', '2022-08-27 10:36:49', NULL),
(9, 'Rajshahi', '', '2022-08-27 10:37:52', NULL),
(10, 'Sylhet', '', '2022-08-27 10:38:13', NULL),
(11, 'Chattogram', '', '2022-08-27 10:38:45', NULL),
(12, 'Barishal', '', '2022-08-27 10:39:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(4, 3, '3G/2G', '2022-07-02 17:48:41', NULL),
(5, 3, '4G', '2022-07-02 17:49:06', NULL),
(6, 3, 'slow speed', '2022-08-27 10:42:32', NULL),
(7, 3, 'No connection', '2022-08-27 10:43:07', NULL),
(8, 4, 'low signal', '2022-08-27 10:43:26', NULL),
(9, 5, 'No 4G', '2022-08-27 10:43:45', NULL),
(10, 5, 'slow speed', '2022-08-27 10:43:56', NULL),
(11, 7, 'Stop Vas service', '2022-08-27 10:44:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomplaints`
--

CREATE TABLE `tblcomplaints` (
  `complaintNumber` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `complaintType` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `noc` varchar(255) DEFAULT NULL,
  `complaintDetails` mediumtext DEFAULT NULL,
  `complaintFile` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomplaints`
--

INSERT INTO `tblcomplaints` (`complaintNumber`, `userId`, `category`, `subcategory`, `complaintType`, `state`, `noc`, `complaintDetails`, `complaintFile`, `regDate`, `status`, `lastUpdationDate`) VALUES
(2, 2, 3, 'slow speed', 'General', 'Dhaka', '', 'Test Data', '', '2022-08-27 16:51:39', 'proccessing', '2022-08-27 17:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `logout` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(51, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-12 10:33:48', '', 1),
(52, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-12 11:24:59', '', 0),
(53, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-12 11:40:32', '', 0),
(54, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-12 11:42:48', '', 0),
(55, 0, 'rakibulhasasnshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-12 11:42:59', '', 0),
(56, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-12 11:44:24', '', 1),
(57, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-12 11:58:24', '', 1),
(58, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-23 04:04:29', '', 0),
(59, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:05:36', '', 1),
(60, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:14:01', '', 1),
(61, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:17:47', '', 1),
(62, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:18:40', '', 1),
(63, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:22:36', '', 1),
(64, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-23 04:24:12', '23-08-2022 09:54:16 AM', 1),
(65, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 11:22:06', '', 1),
(66, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 11:42:33', '', 1),
(67, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 11:49:02', '', 1),
(68, 0, 'anuj.lpu1@gmail.co', 0x3a3a3100000000000000000000000000, '2022-08-26 11:49:09', '', 0),
(69, 0, 'anuj.lpu1@gmail.co', 0x3a3a3100000000000000000000000000, '2022-08-26 11:50:48', '', 0),
(70, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 11:51:09', '', 1),
(71, 0, 'anuj.lpu1@gmail.co', 0x3a3a3100000000000000000000000000, '2022-08-26 12:12:53', '', 0),
(72, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 12:12:59', '', 1),
(73, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-26 15:45:55', '', 0),
(74, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-26 16:28:41', '', 0),
(75, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-26 18:52:09', '', 0),
(76, 0, '', 0x3a3a3100000000000000000000000000, '2022-08-26 18:52:22', '', 0),
(77, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 18:52:31', '', 1),
(78, 0, '', 0x3a3a3100000000000000000000000000, '2022-08-26 19:01:41', '', 0),
(79, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 19:01:43', '27-08-2022 01:36:12 AM', 1),
(80, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-26 20:06:24', '', 1),
(81, 1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 09:07:47', '', 1),
(82, 0, 'rakib', 0x3a3a3100000000000000000000000000, '2022-08-27 09:51:33', '', 0),
(83, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 09:51:52', '', 1),
(84, 0, 'admin ', 0x3a3a3100000000000000000000000000, '2022-08-27 10:33:54', '', 0),
(85, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 10:34:05', '', 1),
(86, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 10:45:06', '', 1),
(87, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 11:24:21', '', 1),
(88, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 11:34:07', '', 1),
(89, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 11:45:44', '', 1),
(90, 3, 'rakibul.showrov@northsouth.edu', 0x3a3a3100000000000000000000000000, '2022-08-27 12:01:43', '', 1),
(91, 0, 'admin', 0x3a3a3100000000000000000000000000, '2022-08-27 12:29:30', '', 0),
(92, 0, 'admin', 0x3a3a3100000000000000000000000000, '2022-08-27 12:38:48', '', 0),
(93, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 12:38:54', '', 1),
(94, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 12:44:46', '', 1),
(95, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 12:50:56', '', 1),
(96, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 15:16:14', '', 1),
(97, 0, 'admin', 0x3a3a3100000000000000000000000000, '2022-08-27 15:23:51', '', 0),
(98, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 15:24:08', '', 1),
(99, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 16:35:16', '', 1),
(100, 2, 'rakibulhasanshowrov@gmail.com', 0x3a3a3100000000000000000000000000, '2022-08-27 16:38:53', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactNo` bigint(11) DEFAULT NULL,
  `address` tinytext DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `userImage` varchar(255) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `userEmail`, `password`, `contactNo`, `address`, `State`, `country`, `pincode`, `userImage`, `regDate`, `updationDate`, `status`) VALUES
(2, 'RHS', 'rakibulhasanshowrov@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 162636082, NULL, NULL, NULL, NULL, NULL, '2022-07-02 14:21:48', NULL, 1),
(3, 'rakib', 'rakibul.showrov@northsouth.edu', '25d55ad283aa400af464c76d713c07ad', 1740209802, NULL, NULL, NULL, NULL, NULL, '2022-08-27 09:51:13', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaintremark`
--
ALTER TABLE `complaintremark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  ADD PRIMARY KEY (`complaintNumber`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `complaintremark`
--
ALTER TABLE `complaintremark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  MODIFY `complaintNumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
