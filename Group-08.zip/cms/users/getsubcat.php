<?php
include('includes/config.php');
$category_id = $_POST["category_id"];
$stmt = mysqli_query($con,"SELECT subcategory FROM subcategory WHERE categoryid ='$category_id'");
?>
<option value="">Select Sub Category</option>
<?php
while ($row = mysqli_fetch_array($stmt)) {
    ?>
    <option value="<?php echo htmlentities($row['subcategory']); ?>"><?php echo htmlentities($row['subcategory']); ?></option>
    <?php
}
?>