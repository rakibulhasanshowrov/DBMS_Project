<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Dhaka');
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{
$sql=mysqli_query($con,"SELECT password FROM  users where password='".md5($_POST['password'])."' && userEmail='".$_SESSION['login']."'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update users set password='".md5($_POST['newpassword'])."', updationDate='$currentTime' where userEmail='".$_SESSION['login']."'");
$successmsg="Password Changed Successfully";
}
else
{
$errormsg="Old Password not match ";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>

    <title>CMS | User Change Password</title>

  
  </head>

  <body>
     <?php include("includes/header.php");?>
      <?php include("includes/option.php");?>
      <div class="main"> 
          	<h1> Change Password</h1>
            <div class="outer"> 
              <div clas="inner"> 
                                            <form  method="post" name="chngpwd" onSubmit="return valid();">
                              <label> <strong>Current Password</label>
                              <br>
                                  <input type="password" name="password" required="required">
                              
                          <br>
                              <label >New Password</label>
                              <br>
                                  <input type="password" name="newpassword" required="required">
                            

                                  <br>
                              <label>Confirm Password</label>
                              <br>
                                  <input type="password" name="confirmpassword" required="required" >
                                  <br>                                  
                                  <button type="submit" name="submit" >Submit</button>


                          </form>
                          </div>
                          </div>
                          
  </body>
</html>
<?php } ?>
