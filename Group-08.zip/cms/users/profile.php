<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Dhaka');
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{
$fname=$_POST['fullname'];
$contactno=$_POST['contactno'];
$address=$_POST['address'];
$state=$_POST['state'];
$country=$_POST['country'];
$pincode=$_POST['pincode'];
$query=mysqli_query($con,"update users set fullName='$fname',contactNo='$contactno',address='$address',State='$state',country='$country',pincode='$pincode' where userEmail='".$_SESSION['login']."'");
if($query)
{
$successmsg="Profile updated Successfully !!";
}
else
{
$errormsg="Profile not updated !!";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
    <title>CMS | User Change Password</title>

    <
  
  </head>

  <body>

     <?php include("includes/header.php");?>
      <?php include("includes/option.php");?>
      <div class="main">    	
      <h1> Profile info</h1>
            <div class="outer"> 
              <div clas="inner">                    
 <?php $query=mysqli_query($con,"select * from users where userEmail='".$_SESSION['login']."'");
 while($row=mysqli_fetch_array($query)) 
 {
 ?>                     

  <h4 ><?php echo htmlentities($row['fullName']);?>'s Profile</h4>
    <h5><b>Last Updated at :</b><?php echo htmlentities($row['updationDate']);?></h5>
                      <form method="post" name="profile" >

<div>
<label><strong>Full Name</label>
<br>
<input type="text" name="fullname" required="required" value="<?php echo htmlentities($row['fullName']);?>" >
<br><label>User Email </label><br>
 
<input type="email" name="useremail" required="required" value="<?php echo htmlentities($row['userEmail']);?>"  readonly>
<br>


<label >Contact</label>
<br>
<input type="text" name="contactno" required="required" value="<?php echo htmlentities($row['contactNo']);?>" >
<br>
<label >Address </label>
<br>
<textarea  name="address" required="required"><?php echo htmlentities($row['address']);?></textarea>
<br>
<label >District</label>
<br>
<select name="state" required="required" >
<option value="<?php echo htmlentities($row['State']);?>"><?php echo htmlentities($st=$row['State']);?></option>
<?php $sql=mysqli_query($con,"select stateName from state ");
while ($rw=mysqli_fetch_array($sql)) {
  if($rw['stateName']==$st)
  {
    continue;
  }
  else
  {
  ?>
  <option value="<?php echo htmlentities($rw['stateName']);?>"><?php echo htmlentities($rw['stateName']);?></option>
<?php
}}
?>

</select>
<br>
<label>Country</label>
<br>
<input type="text" name="country" required="required" value="<?php echo htmlentities($row['country']);?>" class="form-control">
<br>
<label >Pincode</label>
<br>
<input type="text" name="pincode" maxlength="6" required="required" value="<?php echo htmlentities($row['pincode']);?>" class="form-control">
<br>
<label class="col-sm-2 col-sm-2 control-label">Reg Date </label>
<br>
<input type="text" name="regdate" required="required" value="<?php echo htmlentities($row['regDate']);?>" class="form-control" readonly>
<br>
<label>User Photo</label>
<div >
<?php $userphoto=$row['userImage'];
if($userphoto==""):
?>
<img src="userimages/noimage.png" width="256" height="256" >
<a href="update-image.php">Change Photo</a>
<?php else:?>
	<img src="userimages/<?php echo htmlentities($userphoto);?>" width="256" height="256">
	<a href="#">Change Photo</a>
<?php endif;?>
<?php } ?>

                         
<button type="submit" name="submit">Submit</button>

                          </form>
</div>
</div>
</div>
  </body>
</html>
<?php } ?>
