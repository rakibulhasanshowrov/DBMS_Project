 <footer >
          <div >
              Complaints Management System
              <a href="#">
                  <i></i>
              </a>
          </div>
      </footer>