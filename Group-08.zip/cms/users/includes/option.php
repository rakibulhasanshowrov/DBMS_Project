<div>
              <ul>            
                              <?php $query=mysqli_query($con,"select fullName,userImage from users where userEmail='".$_SESSION['login']."'");
 while($row=mysqli_fetch_array($query)) 
 {
 ?> 
                  <p><a href="profile.php">
<?php $userphoto=$row['userImage'];
if($userphoto==""):
?>
<img src="userimages/noimage.png" width="70" height="70" >
<?php else:?>
  <img src="userimages/<?php echo htmlentities($userphoto);?>" width="70" height="70">

<?php endif;?>
</a>
</p>
 
                  <h3><?php echo htmlentities($row['fullName']);?></h3>
                  <?php } ?>
                  <li >
                      <a href="dashboard.php">
                      
                          Dashboard
                      </a>
                  </li>


                  <li>
                      <a href="javascript:;" >
                          Account Setting
                      </a>
                      <ul>
                          <li><a  href="profile.php">Profile</a></li>
                          <li><a  href="change-password.php">Change Password</a></li>
                        
                      </ul>
                  </li>
                  <li >
                      <a href="register-complaint.php" >
                          
                          Lodge Complaint
                      </a>
                    </li>
                  </li>
                  <li>
                      <a href="complaint-history.php" >
                          Complaint History
                      </a>
                  </li>
                 
              </ul>
             
              </div>
        </nav>
</div>