 <header >
    <style>
        body{
            background-color:#8F3A8433;
        }
        ul{
    list-style: none;
    background-color:aqua;
}

a{
    display: block;
    padding: 0 28px;
    border:plain;
    text-decoration: none;
    color:black;
    text-align:left;
}
li{
    float:none;
    font-weight: bold;
    border-right: 2px solid whitesmoke;
}
a:hover{
    background-color: blueviolet;
}
    .main1{
        background-color:aqua;
    }
</style>
    
            
            <div class="main1">
            <h1>Complaint Management System</h1>
                </div>
            <div> 
                <nav>
            	<ul>
                <li><a href="http://localhost/cmafinal/index.html">Back To main page</a>
                    <li><a href="logout.php">Logout</a></li>
                    
            	</ul>
</nav>
        </header>