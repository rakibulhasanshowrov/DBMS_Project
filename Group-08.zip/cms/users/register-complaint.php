<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
if(isset($_POST['submit']))
{
$uid=$_SESSION['id'];
$category=$_POST['category'];
$subcat=$_POST['subcategory'];
$complaintype=$_POST['complaintype'];
$state=$_POST['state'];
$noc=$_POST['noc'];
$complaintdetials=$_POST['complaindetails'];
$compfile=$_FILES["compfile"]["name"];

$sql=mysqli_query($con,"select complaintNumber from tblcomplaints  order by complaintNumber desc limit 1");
while($row=mysqli_fetch_array($sql))
{
 $cmpn=$row['complaintNumber'];
}
$complainno=$cmpn;
move_uploaded_file($_FILES["compfile"]["tmp_name"],"complaintdocs/".$_FILES["compfile"]["name"]);
$query=mysqli_query($con,"insert into tblcomplaints(complaintNumber,userId,category,subcategory,complaintType,state,noc,complaintDetails,complaintFile) values('$complainno','$uid','$category','$subcat','$complaintype','$state','$noc','$complaintdetials','$compfile')");
$sql=mysqli_query($con,"select complaintNumber from tblcomplaints  order by complaintNumber desc limit 1");
while($row=mysqli_fetch_array($sql))
{
 $cmpn=$row['complaintNumber'];
}
$complainno=$cmpn;
echo '<script> alert("Your complain has been successfully filled and your complaintno is  "+"'.$complainno.'")</script>';
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <script>
function getCat(val) {
  

  $.ajax({
  type: "POST",
  url: "getsubcat.php",
  data:'catid='+val,
  success: function(data){
    $("#subcategory").html(data);
    
  }
  });
  }
  </script>
    <style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
  
  </head>

  <body>

     <?php include("includes/header.php");?>
      <?php include("includes/option.php");?>
      <div class="main"> 
          	<h1> Register Complaint</h1>
            <div class="outer"> 
              <div clas="inner"> 
<label for="CATEGORY-DROPDOWN"><strong>Category</label>
<br>
<select name="category" id="category-dropdown" onChange="getCat(this.value);"  required="">
<option value="">Select Category</option>
<?php $sql=mysqli_query($con,"select id,categoryName from category ");
while ($rw=mysqli_fetch_array($sql)) {
  ?>
  <option value="<?php echo htmlentities($rw['id']);?>"><?php echo htmlentities($rw['categoryName']);?></option>
  <br>
<?php
}
?>
</select>
<br>
<label for="SUBCATEGORY">Sub Category </label>
<br>
<select name="subcategory" id="sub-category-dropdown" >
<option value="">Select Subcategory </option>
</select>

<br>
<label >Complaint Type</label>
<br>
<div >
<select name="complaintype" class="form-control" required="">
                <option value=" Complaint"> Complaint</option>
                  <option value="General Query">General Query</option>
                </select> 
                <br>
<label >District</label>
<br>
<select name="state" required="required">
<option value="">Select State</option>
<?php $sql=mysqli_query($con,"select stateName from state ");
while ($rw=mysqli_fetch_array($sql)) {
  ?>
  <option value="<?php echo htmlentities($rw['stateName']);?>"><?php echo htmlentities($rw['stateName']);?></option>
<?php
}
?>

</select>

<br>
<label >Nature of Complaint</label>
<br>
<input type="text" name="noc" required="required" value="" required="" >
<br>

<label >Complaint Details </label>
<br>
<textarea  name="complaindetails" required="required" cols="30" rows="10" maxlength="2000"></textarea>
<br>
<label >Complaint Related Documents(Optional) </label>
<br>
<input type="file" name="compfile" >
<br>

<button type="submit" style="color:red" name="submit" >Submit</button>
<br>

                          </form>
                          </div>
                          </div>
                          <script src="https://code.jquery.com/jquery-3.5.1.min.js"  crossorigin="anonymous"></script>
                          <script>
                           $(document).ready(function() {
                $('#category-dropdown').on('change', function() {
                    var category_id = this.value;
                    $.ajax({
                        url: "getsubcat.php",
                        type: "POST",
                        data: {
                            category_id: category_id
                        },
                        cache: false,
                        success: function(data) {
                            $("#sub-category-dropdown").append(data);
                        }
                    });
                });
            });
        </script>
  </body>
</html>
<?php } ?>
