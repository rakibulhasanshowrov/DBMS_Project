<?php session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{ ?>

<!DOCTYPE html>
<html lang="en">
  <head>
     <style>
      table, th, td {
  border: 1px solid;
}
      h1{
        text-align: center;
      }
      
#dtable{
            color: black;
            background-color: 009900;
            margin: 2px;
            font-size: 25px;
}

</style>
    <title>CMS | Dashboard</title>  
    
  </head>

  <body>
  <?php include("includes/header.php");?>
  <?php include("includes/option.php");?>
                                <?php 
                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where userId='".$_SESSION['id']."' and status is null");
$num1 = mysqli_num_rows($rt);
{?>                <H1> Dashboard</h3>
					  			<div style="text-align:center;background-color:#FDCFF6;width:230px;;margin: 0 auto;border-style:inset ;">
					  			<table><tr>
                    <th><?php echo htmlentities($num1);?> Complaints not Process yet</th></tr>
</table>
                  		
                      <?php }?>
                    <?php 
  $status="in Process";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where userId='".$_SESSION['id']."' and  status='$status'");
$num1 = mysqli_num_rows($rt);
{?>
                  
                  <table><tr>
                    <th><?php echo htmlentities($num1);?> Complaints is in processing</th></tr>
</table>
                      
  <?php }?>

                       <?php 
  $status="closed";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where userId='".$_SESSION['id']."' and  status='$status'");
$num1 = mysqli_num_rows($rt);
{?>
                  <table><tr>
                    <th><?php echo htmlentities($num1);?> Complaint has been Solved</th></tr>
</table>
</div>
<?php }?>
                  	
                  	
                  	</div>	
                  
  </body>
</html>
<?php } ?>
