<?php
include('includes/config.php');
error_reporting(0);
if(isset($_POST['submit']))
{
	$fullname=$_POST['fullname'];
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	$contactno=$_POST['contactno'];
	$status=1;
	$query=mysqli_query($con,"insert into users(fullName,userEmail,password,contactNo,status) values('$fullname','$email','$password','$contactno','$status')");
	$msg="Registration successfull. Now You can login !";
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <Style>
		body  
{  
    margin: 0;  
    padding: 0;  
    background-color:#6abadeba;  
    font-family: 'Arial';  
}  
.login{  
        width: 382px;  
        overflow: hidden;  
        margin: auto;  
        margin: 20 0 0 450px;  
        padding: 80px;  
        background: #23463f;  
        border-radius: 15px ;  
          
}  
h2{  
    text-align: center;  
    color: black;  
    padding: 20px;  
}  
label{  
    color: #08ffd1;  
    font-size: 17px;  
}  
#username{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
}  
#password{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
      
}  
#log{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 17px;  
    padding-left: 7px;  
    color: blue;  
  
  
}  
span{  
    color: white;  
    font-size: 17px;  
}  
a{  
    float: left;  
    background-color: none;  
	color:#ed0909;
} 
	 </Style>
    <title>User Registration</title>
  </head>

  <body>
		      <form class="form-login" name="login" method="post">
		        <h2>User Registration</h2>
		        <p>
		        	<?php if($msg){
echo htmlentities($msg);
		        		}?>


		        </p>
		        <div >
	  	<div >
		  <div class="login">
				<form id="login" method="get" action="login.php">
				<label><b>User Name     
                 </b>    
                 </label>
				 <br>
		         <input type="text" placeholder="Full Name" name="fullname" required="required" autofocus>
		            <br>
					<label><b>Email    
                      </b>    
                    </label> 
					<br>
		            <input type="email"  placeholder="Email ID" id="email" onBlur="userAvailability()" name="email" required="required">
		            
		            <br>
					<label><b>Password     
                      </b>    
                    </label> 
					<br>
		            <input type="password"  placeholder="Password" required="required" name="password">
					<br >
					<label><b>Contact Number     
                      </b>    
                    </label> 
					<br>
		             <input type="text" maxlength="10" name="contactno" placeholder="Contact no" required="required" autofocus>
		            <br>
		            
		            <button  type="submit" name="submit" id="submit">Register</button>
		            <hr>
		            
		            <div>
		                Already Registered<br/>
		                <a href="index.php">
		                   Sign in
		                </a>
						<br><hr>
						<a href="../index.html" style="color:black background-color:aqua;" >Back To Main page</a>
		            </div>
		
		        </div>
		
		      
		
		      </form>	  	
	  	
	  	</div>
	  </div>
	 
  </body>
</html>
