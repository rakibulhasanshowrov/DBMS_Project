<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <style>
     table {
        border-collapse: collapse;
        width: 100%;
      }
      tr {
        background-color: #A1ECFC;
      }
      th,
      td {
        padding: 15px;
        color:black;
        text-align: left;
        border-bottom: 1px solid #ccc;
      }
      tr:hover {
        background-color: #cdcdcd;
      }
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
    
    <title>CMS | Complaint History</title>
  </head>

  <body>

<?php include("includes/header.php");?>
<?php include("includes/option.php");?>

<div class="main">
          	<h1>Your Complaint History</h1>
            <div class="outer"> 
              <div clas="inner">
                            <table>
                              
                              <tr >
                                  <th>Complaint Number</th>
                                  <th>Reg Date</th>
                                  <th>last Updation date</th>
                                  <th>Status</th>
                                  
                              </tr>
                              
                              <tbody>
  <?php $query=mysqli_query($con,"select * from tblcomplaints where userId='".$_SESSION['id']."'");
while($row=mysqli_fetch_array($query))
{
  ?>
                              <tr>
                                  <td><?php echo htmlentities($row['complaintNumber']);?></td>
                                  <td><?php echo htmlentities($row['regDate']);?></td>
                                 <td><?php echo  htmlentities($row['lastUpdationDate']);

                                 ?></td>
                                  <td><?php 
                                    $status=$row['status'];
                                    if($status=="" or $status=="NULL")
                                    { ?>
                                      <button type="button" >Not Process Yet</button>
                                   <?php }
 if($status=="in process"){ ?>
<button type="button" >In Process</button>
<?php }
if($status=="closed") {
?>
<button type="button" >Closed</button>
<?php } ?>
                                   
                                </tr>
</div>
                              <?php } ?>
                            
                              </tbody>
</table>
</div>
</div>
</div>
		  	
  </body>
</html>
<?php } ?>
