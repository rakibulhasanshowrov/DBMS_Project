
<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Dhaka');
$currentTime = date( 'd-m-Y h:i:s A', time () );


if(isset($_POST['submit']))
{
	$state=$_POST['state'];
	$description=$_POST['description'];
$sql=mysqli_query($con,"insert into state(stateName,stateDescription) values('$state','$description')");
$_SESSION['msg']="State added Successfully !!";

}

if(isset($_GET['del']))
		  {
		          mysqli_query($con,"delete from state where id = '".$_GET['id']."'");
                  $_SESSION['delmsg']="State deleted !!";
		  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
	  label{
		color:black;
	  }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
	<title>Admin| State</title>
</head>
<body>
<?php include('include/header.php');?>
<?php include('include/option.php');?>	
<div class="main"> 			
								<h1>District</h1>
								<div class="outer"> 
              <div clas="inner">
								
			<form  name="Category" method="post" >
								
<label for="basicinput"><strong>District Name</label>
<br>
<input type="text" placeholder="Enter District Name"  name="state"  required>
<br>

											<label  for="basicinput">Description</label>
											<br>
												<textarea  name="description" rows="5"></textarea>
												<br>
												<button type="submit" name="submit" >Create</button>
											
									</form>
							</div>
						</div>

</body>
<?php } ?>