
<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Dhaka');
$currentTime = date( 'd-m-Y h:i:s A', time () );
if(isset($_POST['submit']))
{
$sql=mysqli_query($con,"SELECT password FROM  admin where password='".md5($_POST['password'])."' && username='".$_SESSION['alogin']."'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $con=mysqli_query($con,"update admin set password='".md5($_POST['newpassword'])."', updationDate='$currentTime' where username='".$_SESSION['alogin']."'");
$_SESSION['msg']="Password Changed Successfully!";
}
else
{
$_SESSION['msg']="Password not match!";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin| Change Password</title>
</head>
<body>
<?php include('include/header.php');?>

<?php include('include/option.php');?>
<div class="main"> 
          	 		

								<h3>Admin Change Password</h3>						
            <div class="outer"> 
              <div clas="inner">
									<?php if(isset($_POST['submit']))
{?>
									
										<button type="button" data-dismiss="alert">×</button>
										<?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
									</div>
<?php } ?>
									<br />

			<form  name="chngpwd" method="post" onSubmit="return valid();">
									
<label for="basicinput"><strong>Current Password</label>
<br>
<input type="password" placeholder="Enter your current Password"  name="password"  required>
<br>
<label for="basicinput">New Password</label>
<br>
<input type="password" placeholder="Enter your new current Password"  name="newpassword"  required>
<br>
<label for="basicinput">New Password</label>
<br>
<input type="password" placeholder="Enter your new Password again"  name="confirmpassword" required>
<br>							
<button type="submit" name="submit" class="btn">Submit</button>
<br>
</form>
</body>
<?php } ?>