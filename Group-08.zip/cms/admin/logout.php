<?php
session_start();
$_SESSION['alogin']=="";
session_unset();
//$_SESSION['flash_message'] ="You have successfully logout";
$_SESSION['errmsg']="You have successfully logout";
?>
