<div>
<ul >
							<li>
								<a href="#" >
									Manage Complaint
								</a>
								<ul >
									<li>
										<a href="notprocess-complaint.php">
											Not Process Yet Complaint
											<?php
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status is null");
$num1 = mysqli_num_rows($rt);
{?>
		
											<b><?php echo htmlentities($num1); ?></b>
											<?php } ?>
										</a>
									</li>
									<li>
										<a href="inprocess-complaint.php">
											Pending Complaint
                   <?php 
  $status="in Process";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status='$status'");
$num1 = mysqli_num_rows($rt);
{?><b ><?php echo htmlentities($num1); ?></b>
<?php } ?>
										</a>
									</li>
									<li>
										<a href="closed-complaint.php">	
											Closed Complaints
	     <?php 
  $status="closed";                   
$rt = mysqli_query($con,"SELECT * FROM tblcomplaints where status='$status'");
$num1 = mysqli_num_rows($rt);
{?><b ><?php echo htmlentities($num1); ?></b>
<?php } ?>

										</a>
									</li>
								</ul>
							</li>
							
							<li>
								<a href="manage-users.php">
									Manage users
								</a>
							</li>
						</ul>


						<ul>
                                <li><a href="category.php"> Add Category </a></li>
                                <li><a href="subcategory.php">Add Sub-Category </a></li>
                                <li><a href="state.php">Add District</a></li>
                            </ul>
						<ul>
						<li>
								<a href="http://localhost/cmafinal/index.html">							
									Back to main portal
								</a>
							</li>	
						<li>
								<a href="logout.php">							
									Logout
								</a>
							</li>
						</ul>

					</div>
				</div>
