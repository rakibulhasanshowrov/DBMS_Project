<style>
        body{
            background-color:#8F3A8433;
        }
		h1{
			text-align:center;
		}
        ul{
    list-style: none;
    background-color:aqua;
}

a{
    display: block;
    padding: 0 28px;
    border:plain;
    text-decoration: none;
    color:black;
    text-align:left;
}
li{
    float:none;
    font-weight: bold;
    border-right: 2px solid whitesmoke;
}
a:hover{
    background-color: blueviolet;
}
    .main1{
        background-color:aqua;
    }
</style>

			<div class="main1">
            <h1>Complaint Management System</h1>
			<h1>Admin Portal</h1>
                </div>
					<ul >
						<li >
							<a href="#">
								<img src="images/user.png" alt="admin pic" width="300px" height="300px" />
							</a>
							<ul>
								<li><a href="change-password.php">Change Password</a></li>
								<li></li>
							</ul>
	</div><!-- /navbar -->
