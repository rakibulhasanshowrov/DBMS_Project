
<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$subcat=$_POST['subcategory'];
$sql=mysqli_query($con,"insert into subcategory(categoryid,subcategory) values('$category','$subcat')");
$_SESSION['msg']="SubCategory Created !!";

}

if(isset($_GET['del']))
		  {
		          mysqli_query($con,"delete from subcategory where id = '".$_GET['id']."'");
                  $_SESSION['delmsg']="SubCategory deleted !!";
		  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
      h1{
        color: black;
font-family: arial, sans-serif;
font-size: 16px;
font-weight: bold;
margin-top: 0px;
margin-bottom: 1px;
      }
      .main{     
border: 5px solid #FFFF00;
text-align: center;
      }
            .outer {
                background-color: #006699;
                color: #fff;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
            .inner {
                background-color: #efefef;
                color: #000;
                height: auto;
                width: auto;
                margin: 0px auto;
            }
        </style>
	<title>Admin| SubCategory</title>
</head>
<body>
<?php include('include/header.php');?>
<?php include('include/option.php');?>				
			<div class="main">
								<h1>Sub Category</h1>
								<div class="outer">
									<div class="inner">
			<form  name="subcategory" method="post" >
<label for="basicinput">Category</label>
<br>
<select name="category" required>
<option value="">Select Category</option> 
<?php $query=mysqli_query($con,"select * from category");
while($row=mysqli_fetch_array($query))
{?>

<option value="<?php echo $row['id'];?>"><?php echo $row['categoryName'];?></option>
<?php } ?>
</select>
<br>
<label for="basicinput">SubCategory Name</label>
<br>
<input type="text" placeholder="Enter SubCategory Name"  name="subcategory" required>
<br>
												<button type="submit" name="submit" >Create</button> <br>
									
									</form>
							</div>
						</div>
						</div>
	
</body>
<?php } ?>